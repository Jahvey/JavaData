
	var users = new Array(
		{username:"lcb",password:"lcb"},
		{username:"tom",password:"tom"},
		{username:"tim",password:"tim"},
		{username:"jerry",password:"jerry"}
	);
